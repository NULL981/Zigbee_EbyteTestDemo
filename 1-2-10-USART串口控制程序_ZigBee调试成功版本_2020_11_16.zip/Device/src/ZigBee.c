#include "ZigBee.h"
#include "stm32f10x.h" 



ZigBee newZigBee(){
    ZigBee zb;
    zb.sendData = sendData;
    return zb;
}


bool sendData(ZigBeeMsg *zbMsg,MsgType msgType){
    char data[] = {0xFC,0x05,0x02,0x01,0x31,0x32,0x33};//FC 05 01 02 31 32 33
    int i;
    bool flag = false;
    switch(msgType){
        case BROADCAST:

            break;
        case MULTICAST:
            break;
        case POINT_TO_POINT:
            uart_sendBytes((char*)(&data),7);
            
            
            break;
    }

    return false;
}


bool uart_sendBytes(char* pData,unsigned char dataLen){
	static unsigned step = 0;
	static unsigned curIndex = 0;
	//char* pDataTemp = pData;

	if(dataLen == 0){
		return false;		
	}
	switch(step){
		case 0:
			if(curIndex < dataLen){
				
				step++;
			}else{
				return true;
			}
			
			break;
		case 1:
			pData+=curIndex;
			USART_SendData(USART1,*pData);
			curIndex++;
			step++;
			break;
		case 2:
			if(USART_GetFlagStatus(USART1,USART_FLAG_TC) == SET){//is Transmission Complete?
				step = 0;
			}
			break;
	}
	
	return false;
	

}
