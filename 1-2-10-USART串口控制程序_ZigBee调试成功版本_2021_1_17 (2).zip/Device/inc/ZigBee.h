/**
 * @brief ZigBee Moudle
 * @time 2020-11-14
 * 
*/

#ifndef ZIGBEE_H
#define ZIGBEE_H
#ifndef _STDBOOL_H
	#include <stdbool.h>
#endif




//typedef struct ZigBeeMsg{
//	unsigned char dataLen;
//	char* pData;
//}ZigBeeMsg;

typedef struct {
	//unsigned char dataPackLen;
	unsigned char len;
	unsigned char data[8];
}ZigBeeMsg;

typedef enum MsgType{
	BROADCAST,//广播
	MULTICAST,//组播
	POINT_TO_POINT //点播
}MsgType;
typedef struct ZigBee{
	bool (*sendData)(ZigBeeMsg *zbMsg,MsgType msgType);
}ZigBee;

ZigBee newZigBee();
bool sendData(ZigBeeMsg *zbMsg,MsgType msgType);
bool uart_sendBytes(char* pData,unsigned char dataLen);

bool ZigBeeSend(ZigBeeMsg* pMsg);
#endif


