#include "stm32f10x.h" 
#include "ZigBee.h"


ZigBee newZigBee(){
    ZigBee zb;
    zb.sendData = sendData;
    return zb;
}


bool sendData(ZigBeeMsg *zbMsg,MsgType msgType){
    char data[] = {0xFC,0x05,0x02,0x01,0x31,0x32,0x33};//FC 05 01 02 31 32 33
    int i;
    bool flag = false;
    switch(msgType){
        case BROADCAST:

            break;
        case MULTICAST:
            break;
        case POINT_TO_POINT:
            uart_sendBytes((char*)(&data),7);
            
            
            break;
    }

    return false;
}


bool uart_sendBytes(char* pData,unsigned char dataLen){
	static unsigned step = 0;
	static unsigned curIndex = 0;
	//char* pDataTemp = pData;

	if(dataLen == 0){
		return false;		
	}
	switch(step){
		case 0:
			if(curIndex < dataLen){
				
				step++;
			}else{
				return true;
			}
			
			break;
		case 1:
			pData+=curIndex;
			USART_SendData(USART1,*pData);
			curIndex++;
			step++;
			break;
		case 2:
			if(USART_GetFlagStatus(USART1,USART_FLAG_TC) == SET){//is Transmission Complete?
				step = 0;
			}
			break;
	}
	
	return false;
	

}


//0A 01 02 01 02 03 04 05 06 07 08 
//0xFC,0x05,0x01,0x02,0x31,0x32,0x33
/**
	@brief zigbee���ͺ���
	@param
		pMsg
		
*/
bool ZigBeeSend(ZigBeeMsg* pMsg)
{
	
	#if 0
	static int i;
	char header[] = {0xFC,0x05,0x01,0x02};
	header[1] = 2 + pMsg->len;
	
	

	
	for(i=0;i<sizeof(header)/sizeof(char);){
		USART_SendData(USART1,header[i]);
		
			while(1)
			{
				if(USART_GetFlagStatus(USART1,USART_FLAG_TC) == SET )
				{
					break;
				}
			}
			i++;
	}
	
	for(i=0;i<pMsg->len;i++){
		if(i>8-1){
			return false;
		}
		USART_SendData(USART1,pMsg->data[i]);
		while(USART_GetFlagStatus(USART1,USART_FLAG_TC) != SET);
	}
		

		
	return true;
	#else
	//0xFC,0x05,0x01,0x02,0x31,0x32,0x33
	int i;
	char data[12] = {0xFC,0x05,0x01,0x02};//4+8
	data[1] = 2 + pMsg->len;
	for(i=0;i<pMsg->len;i++){
		data[i+4] = pMsg->data[i];
	}
	return uart_sendBytes(data,4+pMsg->len);
	#endif
	

}















