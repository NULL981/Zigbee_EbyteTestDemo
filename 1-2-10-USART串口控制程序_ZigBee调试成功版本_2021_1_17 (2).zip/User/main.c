#include "stm32f10x.h" 
#include "sys.h"
#include "delay.h"
#include "led.h"
#include "key.h"
#include "buzzer.h"
#include "usart.h"
#include "ZigBee.h"
#include "zigbeeMessage.h"


typedef struct Message{
	unsigned char cobID;
	unsigned char data[3];
}Message;
void send(Message msg);

unsigned char button;
unsigned char step;
uint16_t reviceData;

int main (void){
	u8 a;
	//ZigBee zigBee = newZigBee();
	ZigBeeMsg msg;
	
	char data[] = {0xFC,0x05,0x02,0x01,0x31,0x32,0x33};//组播  指令： 02+ group+data
	//以广播模式 2 向网络广播发送 HEX 数据： 0X31 0X32 0X33
	char data1[] = {0xFC,0x05,0x01,0x02,0x31,0x32,0x33};
	
	char data2[] = {0xFC,6,0x01,0x02,0x38,0x32,0x33,0x34};
	char* pSendData = data2;
	bool flag1 = false;
	
	uint16_t USART1_Data1 = 0xFE01;
	uint16_t USART1_Data2 = 0x01FF;
	
	char str[10];
	unsigned errNum = 1;
	
	RCC_Configuration(); 
	LED_Init();
	KEY_Init();
	BUZZER_Init();
	USART1_Init(115200); 
	
	

	msg.len = 8;
	msg.data[0] = 1;
	msg.data[1] = 2;
	msg.data[2] = 3;
	msg.data[3] = 4;
	msg.data[4] = 5;
	msg.data[5] = 6;
	msg.data[6] = 7;
	msg.data[7] = 8;
	ZigBeeSend(&msg);
	

#if 1	
	while(1){
//		if(false == flag1){
//			if(uart_sendBytes(pSendData,8) == true){
//				flag1 = true;
//			}
//		}	
		
		
		//send(msg);
		//sprintf(str,"ERRO_%d",errNum++);
		//printf("%s",str);
//		printf("W_1");
//		delay_ms(500); 
//		printf("W_2");
		//USART_SendData(USART1,0x00);
		//delay_ms(500); 


		if(USART_GetFlagStatus(USART1,USART_FLAG_RXNE) != RESET){ 
			a =USART_ReceiveData(USART1);
			switch (a){
				case '0':
					GPIO_WriteBit(LEDPORT,LED1,(BitAction)(0));
					printf("%c:LED1 OFF ",a); //
					break;
				case '1':
					GPIO_WriteBit(LEDPORT,LED1,(BitAction)(1));
					printf("%c:LED1 ON ",a); //
					break;
				case '2':
					BUZZER_BEEP1(); 
					printf("%c:BUZZER ",a); 
					break;
				default:
					break;
			}		  
		}

	
		if(!GPIO_ReadInputDataBit(KEYPORT,KEY1)){ 
			delay_ms(20); 
			if(!GPIO_ReadInputDataBit(KEYPORT,KEY1)){
				while(!GPIO_ReadInputDataBit(KEYPORT,KEY1)); 
				printf("KEY1 "); //
			}
		}		 
		if(!GPIO_ReadInputDataBit(KEYPORT,KEY2)){ 
			delay_ms(20); 
			if(!GPIO_ReadInputDataBit(KEYPORT,KEY2)){ 
				while(!GPIO_ReadInputDataBit(KEYPORT,KEY2)); 
				printf("KEY2 "); //
			}
		}	

		if(button == 1){
			
			
			switch(step){
				case 0:
					USART_SendData(USART1,USART1_Data1);//FE 01 
					step++;
					break;
				case 1:
					if(USART_GetFlagStatus(USART1,USART_FLAG_TC) == SET){//is Transmission Complete?
						step++;
					}
					break;
				case 2:
					USART_SendData(USART1,USART1_Data2);// 01 FF
					step++;
					break;
				case 3:
					if(USART_GetFlagStatus(USART1,USART_FLAG_TC) == SET){//is Transmission Complete?
						step++;
					}
					break;
				case 4:
					if(USART_GetFlagStatus(USART1,USART_FLAG_RXNE) != RESET){  
						reviceData =USART_ReceiveData(USART1);
						step++;
					}
					break;
				case 5:
					button = 0;
					break;
				
			}
			
		
			
			
			
			
		}

//      delay_ms(1000); //��ʱ
		
		
	}
	
#endif
	
	
	
	
}





