#ifndef ZIGBEE_MESSAGE_H
#define ZIGBEE_MESSAGE_H



//0xFC,0x05,0x01,0x02,0x31,0x32,0x33
//typedef struct zigbeeMsg{
//	unsigned char dataPackLen;
//	unsigned char len;
//	unsigned char data[8];
//}ZigbeeMsg;




#endif

